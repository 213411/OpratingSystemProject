import tkinter as tk
from tkinter import messagebox
from PIL import ImageTk, Image

global num_processes
global num_resources
global allocation_entries
global max_resources_entries
global available_entries

def show_second_page():
    global num_processes
    global num_resources
    num_processes = int(processes_entry.get())
    num_resources = int(resources_entry.get())
    create_second_page(num_processes, num_resources)

def check_deadlock():
    global allocation_entries
    global max_resources_entries
    global available_entries
    global num_processes
    global num_resources

    # Validate user inputs
    if not validate_inputs():
        return

    allocation = []
    max_resources = []
    available = []

    for i in range(num_processes):
        allocation.append([int(allocation_entries[i][j].get()) for j in range(num_resources)])
        max_resources.append([int(max_resources_entries[i][j].get()) for j in range(num_resources)])
    available = [int(available_entries[j].get()) for j in range(num_resources)]

    # Perform deadlock detection logic (Banker's algorithm) here
    work = available[:]
    finish = [False] * num_processes
    need = []
    safe_path = []

    for i in range(num_processes):
        need.append([max_resources[i][j] - allocation[i][j] for j in range(num_resources)])

    # Iterate until all processes are finished or deadlock is detected
    while True:
        # Find an unfinished process that can be executed
        found = False
        for i in range(num_processes):
            if not finish[i] and all(need[i][j] <= work[j] for j in range(num_resources)):
                # Process can be executed, release allocated resources
                work = [work[j] + allocation[i][j] for j in range(num_resources)]
                finish[i] = True
                safe_path.append(i)
                found = True
                break

        if not found:
            # Deadlock detected, some processes cannot be executed
            messagebox.showinfo("Deadlock Detection", "Deadlock Detected!")
            break
        elif all(finish):
            messagebox.showinfo("Deadlock Detection", "No deadlock will occur.")
            messagebox.showinfo("Safe Path", f"Safe Path: {' -> '.join(['P' + str(p + 1) for p in safe_path])}")
            break

def validate_inputs():
    global allocation_entries
    global max_resources_entries
    global available_entries

    try:
        for i in range(num_processes):
            for j in range(num_resources):
                allocation = int(allocation_entries[i][j].get())
                max_resources = int(max_resources_entries[i][j].get())

                # Check if allocation and max_resources are positive
                if allocation < 0 or max_resources < 0:
                    messagebox.showerror("Input Error", "Allocation and max resources must be positive integers.")
                    return False

        for j in range(num_resources):
            available = int(available_entries[j].get())

            # Check if available resources are positive
            if available < 0:
                messagebox.showerror("Input Error", "Available resources must be positive integers.")
                return False

    except ValueError:
        messagebox.showerror("Input Error", "Invalid input. Please enter integers only.")
        return False

    return True

def create_second_page(num_processes, num_resources):
    global allocation_entries
    global max_resources_entries
    global available_entries
    first_page.destroy()

    second_page = tk.Tk()
    second_page.title("Banker's Algorithm")
    second_page.state('zoomed')

    # Load background image
    background_image = ImageTk.PhotoImage(Image.open("1.jpg"))
    background_label = tk.Label(second_page, image=background_image)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)

    allocation_entries = []
    max_resources_entries = []
    available_entries = []

    for i in range(num_processes):
        allocation_row = []
        max_resources_row = []

        for j in range(num_resources):
            tk.Label(second_page, text=f"Allocation P{i+1}, R{j+1}").grid(row=i, column=2*j, padx=5, pady=5)
            allocation_entry = tk.Entry(second_page)
            allocation_entry.grid(row=i, column=2*j+1, padx=5, pady=5)
            allocation_row.append(allocation_entry)

            tk.Label(second_page, text=f"Max Resources P{i+1}, R{j+1}").grid(row=i+num_processes, column=2*j, padx=5, pady=5)
            max_resources_entry = tk.Entry(second_page)
            max_resources_entry.grid(row=i+num_processes, column=2*j+1, padx=5, pady=5)
            max_resources_row.append(max_resources_entry)

        allocation_entries.append(allocation_row)
        max_resources_entries.append(max_resources_row)

    for j in range(num_resources):
        tk.Label(second_page, text=f"Available Resources R{j+1}").grid(row=2*num_processes, column=2*j, padx=5, pady=5)
        available_entry = tk.Entry(second_page)
        available_entry.grid(row=2*num_processes, column=2*j+1, padx=5, pady=5)
        available_entries.append(available_entry)

    check_button = tk.Button(second_page, text="Check Deadlock", command=check_deadlock, fg="white", bg="gray")
    check_button.grid(row=2*num_processes+1, columnspan=2*num_resources, padx=10, pady=10)
    check_button.bind("<Enter>", lambda event: check_button.config(bg="black"))
    check_button.bind("<Leave>", lambda event: check_button.config(fg="white", bg="gray"))

    second_page.mainloop()

first_page = tk.Tk()
first_page.title("Banker's Algorithm")
first_page.state('zoomed')

# Load background image
background_image = ImageTk.PhotoImage(Image.open("1.jpg"))
background_label = tk.Label(first_page, image=background_image)
background_label.place(x=0, y=0, relwidth=1, relheight=1)

processes_label = tk.Label(first_page, text="Number of Processes:", fg="white", bg="gray")
processes_label.pack(pady=30)

processes_entry = tk.Entry(first_page)
processes_entry.pack()

resources_label = tk.Label(first_page, text="Number of Resources:", fg="white", bg="gray")
resources_label.pack(pady=30)

resources_entry = tk.Entry(first_page)
resources_entry.pack()

continue_button = tk.Button(first_page, text="Continue", command=show_second_page, fg="white", bg="gray")
continue_button.pack(pady=30)
continue_button.bind("<Enter>", lambda event: continue_button.config(bg="black"))
continue_button.bind("<Leave>", lambda event: continue_button.config(fg="white", bg="gray"))

first_page.mainloop()
